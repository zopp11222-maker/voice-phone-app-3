package com.voicephone

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var nameInput: EditText
    private lateinit var serverInput: EditText
    private lateinit var hostSwitch: Switch
    private lateinit var hostInfo: TextView
    private lateinit var connectBtn: Button
    private lateinit var dot: View
    private lateinit var statusText: TextView
    private lateinit var meter: ProgressBar
    private lateinit var micBtn: Button
    private lateinit var listBox: LinearLayout
    private var lastSig = ""

    private val RED = Color.parseColor("#E53935")
    private val GREEN = Color.parseColor("#43A047")
    private val AMBER = Color.parseColor("#FFB300")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun shape(color: Int, oval: Boolean = false, r: Int = 12) = GradientDrawable().apply {
        if (oval) this.shape = GradientDrawable.OVAL else cornerRadius = dp(r).toFloat()
        setColor(color)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("vc", MODE_PRIVATE)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(36), dp(16), dp(24))
        }
        setContentView(ScrollView(this).apply { setBackgroundColor(Color.parseColor("#121212")); addView(root) })

        fun text(t: String, size: Float = 14f, color: Int = Color.WHITE) = TextView(this).apply {
            text = t; textSize = size; setTextColor(color)
        }
        fun input(hint: String, value: String) = EditText(this).apply {
            this.hint = hint; setText(value); setSingleLine()
            setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            background = shape(Color.parseColor("#222222")); setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        fun lp(top: Int = 8) = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top) }

        root.addView(text("🎙 Voice Phone", 24f, Color.parseColor("#66FF66")).apply { gravity = Gravity.CENTER })

        nameInput = input("ชื่อในเกม (พิมพ์ให้ตรงเป๊ะ)", prefs.getString("name", "") ?: "")
        root.addView(nameInput, lp(16))

        hostSwitch = Switch(this).apply {
            text = "เป็นโฮสต์ (รันเซิร์ฟเวอร์ในเครื่องนี้)"; setTextColor(Color.WHITE)
            isChecked = prefs.getBoolean("host", true)
        }
        root.addView(hostSwitch, lp())

        serverInput = input("IP:พอร์ต ของโฮสต์ เช่น 192.168.1.5:8080", prefs.getString("server", "") ?: "")
        root.addView(serverInput, lp())

        hostInfo = text("", 13f, Color.parseColor("#AAAAAA"))
        root.addView(hostInfo, lp())

        connectBtn = Button(this).apply { setTextColor(Color.WHITE); background = shape(Color.parseColor("#22AA88")) }
        root.addView(connectBtn, lp(12))

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = shape(Color.parseColor("#1B1B1B"))
            setPadding(dp(14), dp(14), dp(14), dp(14))
        }
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        dot = View(this)
        row.addView(dot, LinearLayout.LayoutParams(dp(28), dp(28)).apply { rightMargin = dp(12) })
        statusText = text("", 15f).apply { typeface = Typeface.DEFAULT_BOLD }
        row.addView(statusText, LinearLayout.LayoutParams(0, -2, 1f))
        card.addView(row)
        meter = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        card.addView(meter, lp(10))
        root.addView(card, lp(16))

        micBtn = Button(this).apply { textSize = 18f; setTextColor(Color.WHITE) }
        root.addView(micBtn, LinearLayout.LayoutParams(-1, dp(64)).apply { topMargin = dp(12) })

        root.addView(text("👥 รายชื่อผู้เล่นในเซิร์ฟเวอร์", 15f).apply { typeface = Typeface.DEFAULT_BOLD }, lp(20))
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(listBox, lp())

        hostSwitch.setOnCheckedChangeListener { _, _ -> updateHostUi() }
        updateHostUi()

        connectBtn.setOnClickListener {
            if (VoiceService.running) {
                startService(Intent(this, VoiceService::class.java).setAction(VoiceService.ACTION_STOP))
                return@setOnClickListener
            }
            val name = nameInput.text.toString().trim()
            if (name.isEmpty()) { toast("กรุณาใส่ชื่อในเกมก่อน"); return@setOnClickListener }
            if (!hostSwitch.isChecked && serverInput.text.toString().trim().isEmpty()) {
                toast("กรุณาใส่ IP:พอร์ตของโฮสต์"); return@setOnClickListener
            }
            prefs.edit().putString("name", name).putBoolean("host", hostSwitch.isChecked)
                .putString("server", serverInput.text.toString().trim()).apply()
            ensurePermsThenStart()
        }
        micBtn.setOnClickListener {
            if (VoiceService.running && VoiceService.connected)
                startService(Intent(this, VoiceService::class.java).setAction(VoiceService.ACTION_TOGGLE))
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun updateHostUi() {
        val host = hostSwitch.isChecked
        serverInput.visibility = if (host) View.GONE else View.VISIBLE
        hostInfo.text = if (host)
            "ในเกม (เปิดโกงไว้) พิมพ์: /wsserver 127.0.0.1:19131\nให้เพื่อนใส่ที่อยู่: ${localIps()}:8080"
        else "ใส่ที่อยู่ของเครื่องโฮสต์ แล้วกดเชื่อมต่อ"
    }

    private fun localIps(): String = try {
        java.net.NetworkInterface.getNetworkInterfaces().toList().flatMap { it.inetAddresses.toList() }
            .filter { !it.isLoopbackAddress && it is java.net.Inet4Address }
            .joinToString(" / ") { it.hostAddress ?: "" }.ifEmpty { "(ยังไม่ได้ต่อเน็ต)" }
    } catch (e: Exception) { "?" }

    private fun ensurePermsThenStart() {
        val need = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            need += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            need += Manifest.permission.POST_NOTIFICATIONS
        if (need.isEmpty()) startVoice() else requestPermissions(need.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startVoice()
        else toast("ต้องอนุญาตการใช้ไมโครโฟนก่อน")
    }

    private fun startVoice() {
        startForegroundService(Intent(this, VoiceService::class.java)
            .setAction(VoiceService.ACTION_START)
            .putExtra("name", nameInput.text.toString().trim())
            .putExtra("host", hostSwitch.isChecked)
            .putExtra("server", serverInput.text.toString().trim()))
    }

    override fun onResume() { super.onResume(); refresh() }
    override fun onPause() { super.onPause(); ui.removeCallbacksAndMessages(null) }

    private fun refresh() {
        val running = VoiceService.running
        val conn = VoiceService.connected
        val st = VoiceService.status
        val muted = st?.muted ?: true
        connectBtn.text = if (running) "ตัดการเชื่อมต่อ" else "เชื่อมต่อเสียง"
        nameInput.isEnabled = !running; hostSwitch.isEnabled = !running; serverInput.isEnabled = !running

        val color = when {
            !running || !conn -> RED
            st == null || !st.game -> AMBER
            muted -> RED
            else -> GREEN
        }
        dot.background = shape(color, oval = true)
        statusText.text = when {
            !running -> "🔴 ยังไม่ได้เชื่อมต่อ"
            !conn -> VoiceService.message
            st == null -> "…"
            else -> (if (st.mc) "🟢 เชื่อมเกมแล้ว" else "🔴 เกมยังไม่เชื่อม") +
                (if (st.game) " · ระยะ ${st.range} บ." else " · ❓ ไม่พบตัวละครคุณ") +
                (if (st.call.isNotEmpty()) " · 📞 ${st.call}" else "")
        }
        meter.progress = if (running && !muted) ((VoiceService.client?.level ?: 0f) * 100).toInt() else 0

        micBtn.isEnabled = running && conn
        micBtn.text = if (muted) "🔇 ไมค์ปิด (แตะเพื่อเปิด)" else "🎤 ไมค์เปิด (แตะเพื่อปิด)"
        micBtn.background = shape(if (running && conn && !muted) GREEN else RED)

        val players = if (running) st?.players.orEmpty() else emptyList()
        val sig = players.joinToString("|") { "${it.name},${it.muted},${it.call}" }
        if (sig != lastSig) { lastSig = sig; rebuildList(players) }

        ui.postDelayed({ refresh() }, 200)
    }

    private fun rebuildList(players: List<VoiceClient.PlayerInfo>) {
        listBox.removeAllViews()
        if (players.isEmpty()) {
            listBox.addView(TextView(this).apply { text = "ยังไม่มีผู้เล่น"; setTextColor(Color.GRAY) })
            return
        }
        for (p in players) {
            val row = LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL; background = shape(Color.parseColor("#252525"))
                setPadding(dp(10), dp(8), dp(10), dp(8))
            }
            val hue = (Math.abs(p.name.hashCode()) % 360).toFloat()
            val avatar = TextView(this).apply {
                text = p.name.take(1).uppercase(); gravity = Gravity.CENTER; textSize = 18f
                setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
                background = shape(Color.HSVToColor(floatArrayOf(hue, 0.5f, 0.75f)), oval = true)
            }
            row.addView(avatar, LinearLayout.LayoutParams(dp(40), dp(40)).apply { rightMargin = dp(12) })
            row.addView(TextView(this).apply {
                text = p.name + if (p.call.isNotEmpty()) "  📞 ${p.call}" else ""
                setTextColor(Color.WHITE); textSize = 15f
            }, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(TextView(this).apply {
                text = if (p.muted) "🔇 ปิดไมค์" else "🎤 เปิดไมค์"
                setTextColor(Color.WHITE); textSize = 12f; setPadding(dp(8), dp(3), dp(8), dp(3))
                background = shape(if (p.muted) Color.parseColor("#AA2222") else Color.parseColor("#228822"), r = 6)
            })
            listBox.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        }
    }
}
